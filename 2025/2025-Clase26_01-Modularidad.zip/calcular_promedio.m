function res = calcular_promedio(n1, n2, n3)
    res = (n1 + n2 + n3) / 3;
end
