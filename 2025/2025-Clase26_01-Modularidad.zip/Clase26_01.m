numero_1 = input("Ingrese el primer número: ");
numero_2 = input("Ingrese el segundo número: ");
numero_3 = input("Ingrese el tercer número: ");

promedio = calcular_promedio(numero_1, numero_2, numero_3);

fprintf("El promedio es de %.2f\n", promedio);