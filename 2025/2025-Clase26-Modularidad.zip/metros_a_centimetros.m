function cantidad_centimetros = metros_a_centimetros(cantidad_metros)
    %metros = input("Ingrese cantidad de metros: ");
    cantidad_centimetros = cantidad_metros * 100;
    %disp(resultado);
end