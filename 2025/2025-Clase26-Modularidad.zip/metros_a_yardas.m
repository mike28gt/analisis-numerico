function resultado = metros_a_yardas(cantidad_metros)
    %metros = input("Ingrese cantidad de metros: ");
     resultado = cantidad_metros * 1.094;
            %disp(resultado);
end