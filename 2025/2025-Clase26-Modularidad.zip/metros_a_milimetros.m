function resultado = metros_a_milimetros(cantidad_metros)
    %metros = input("Ingrese cantidad de metros: ");
     resultado = cantidad_metros * 1000;
     %disp(resultado);
end