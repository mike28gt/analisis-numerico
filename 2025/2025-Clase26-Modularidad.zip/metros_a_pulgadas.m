function resultado = metros_a_pulgadas(cantidad_metros)
    %metros = input("Ingrese cantidad de metros: ");
     resultado = cantidad_metros * 39.37;
            %disp(resultado);
end