function resultado = metros_a_pies(cantidad_metros)
    %metros = input("Ingrese cantidad de metros: ");
     resultado = cantidad_metros * 3.281;
            %disp(resultado);
end